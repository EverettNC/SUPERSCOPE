Double-click PUT_CLETUS.bat
That is the button.
