"""Seat Cletus in Voice Creation Center. One job. No menu."""
from __future__ import annotations

import shutil
import sys
from pathlib import Path

CENTER = Path(__file__).resolve().parent
WAV_NAME = "cletus.wav"


def _ok(path: Path) -> bool:
    try:
        return path.is_file() and path.stat().st_size > 1024 and path.suffix.lower() == ".wav"
    except OSError:
        return False


def hunt_wavs() -> list[Path]:
    home = Path.home()
    downloads = home / "Downloads"
    roots = [
        CENTER,
        Path.cwd(),
        downloads,
        home / "Desktop",
        home / "Documents",
        home / "Voice_Creation_Center",
    ]
    spots: list[Path] = []
    for root in roots:
        spots.extend(
            [
                root / WAV_NAME,
                root / "incoming" / WAV_NAME,
                root / "packs" / "cletus" / "reference.wav",
            ]
        )
        try:
            if root.is_dir():
                for child in root.iterdir():
                    if child.is_dir():
                        spots.append(child / WAV_NAME)
                        spots.append(child / "incoming" / WAV_NAME)
        except OSError:
            continue
    found: list[Path] = []
    seen: set[Path] = set()
    for raw in spots:
        try:
            path = raw.resolve()
        except OSError:
            continue
        if path in seen or not _ok(path):
            continue
        seen.add(path)
        found.append(path)
    return found


def hunt_center() -> Path:
    if (CENTER / "Voice_registry.py").is_file():
        return CENTER
    home = Path.home()
    for cand in (
        home / "Voice_Creation_Center",
        home / "Documents" / "Voice_Creation_Center",
        home / "Desktop" / "Voice_Creation_Center",
        Path.cwd(),
    ):
        if (cand / "Voice_registry.py").is_file():
            return cand.resolve()
    return CENTER


def seat(src: Path, dest_root: Path) -> Path:
    incoming = dest_root / "incoming"
    pack = dest_root / "packs" / "cletus"
    incoming.mkdir(parents=True, exist_ok=True)
    pack.mkdir(parents=True, exist_ok=True)
    dest = incoming / WAV_NAME
    ref = pack / "reference.wav"
    if src.resolve() != dest.resolve():
        shutil.copy2(src, dest)
    if src.resolve() != ref.resolve():
        shutil.copy2(src, ref)
    manifest = pack / "manifest.json"
    if not manifest.exists():
        manifest.write_text(
            '{\n  "pack_id": "cletus-en-us",\n  "being_name": "cletus",\n'
            '  "language": "en-US",\n  "status": "healthy"\n}\n',
            encoding="utf-8",
        )
    return dest


def main() -> int:
    hits = hunt_wavs()
    if not hits:
        print("NOT FOUND. cletus.wav is not in this folder, incoming, or Downloads.")
        return 1
    dest_root = hunt_center()
    dest = seat(hits[0], dest_root)
    print(f"SEATED {dest}")
    print("Voice Creation Center has Cletus.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
